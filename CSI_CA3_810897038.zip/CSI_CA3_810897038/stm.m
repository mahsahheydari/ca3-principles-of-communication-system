function [xc] = stm(Ac,fc,beta,fm,fs)
t=0:1/fs:1-(1/fs);
xc=Ac*cos((2*pi*fc*t)+beta*sin(2*pi*fm*t));
end