%    fs=10000;
%   t=0:1/fs:((0.2)-(1/fs));
%  [xc]=pmm(sin(20*pi*t),10,100,10,fs) ;
% plot(t,xc) 
% % grid on
% title('pm');                        
% xlabel('time(s)');
% ylabel('$x_c(t)$','interpreter','latex')
% ylim([-20 20])

% % %  fs=10000;
% % %   t=0:1/fs:((0.2)-(1/fs));
% % %  [xnb]=nb(sin(20*pi*t),10,100,10,fs) ;
% % % plot(t,xnb) 
% % % grid on
% % % title('PM NARROWBAND');                        
% % % xlabel('time(s)');
% % % ylabel('$x_nb(t)$','interpreter','latex')
% % % ylim([-100 100])

subplot(2,2,1)
 f=(1000/2)*linspace(-1,1,1000);
x1=stm(10,10,0.1,10,1000);
X1=fftshift(fft(x1));
plot(f,real(X1))
xlim([-500 500]);
title("single tone modulation for \beta=0.1");
xlabel("freq(Hz)");
ylabel("xc");

subplot(2,2,2)
f=(1000/2)*linspace(-1,1,1000);
x2=stm(10,10,1,10,1000);
X2=fftshift(fft(x2));
plot(f,real(X2))
xlim([-500 500]);
title("single tone modulation for \beta=1");
xlabel("freq(Hz)");
ylabel("xc");

subplot(2,2,3)
 f=(1000/2)*linspace(-1,1,1000);
x3=stm(10,10,5,10,1000);
X3=fftshift(fft(x3));
plot(f,real(X3))
xlim([-500 500]);
title("single tone modulation for \beta=5");
xlabel("freq(Hz)");
ylabel("xc");

subplot(2,2,2)
 f=(1000/2)*linspace(-1,1,1000);
x4=stm(10,10,10,10,1000);
X4=fftshift(fft(x4));
plot(f,real(X4))
xlim([-500 500]);
title("single tone modulation for \beta=10");
xlabel("freq(Hz)");
ylabel("xc");

   



