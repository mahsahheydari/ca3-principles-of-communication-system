
function [xnb]=nb(mt,Ac,fc,kp,fs)  
clc
t=0:1/fs:0.2-(1/fs);

xnb=(Ac.*cos(2*pi*fc*t))-(Ac.*sin(2*pi*fc*t).*kp.*mt);
end