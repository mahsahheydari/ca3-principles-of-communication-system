index=0
fs=10000;
keypi=[]
  t=0:1/fs:((0.2)-(1/fs));
for kp=-1:0.01:1 
index=index+1;
[xnb]=nb(sin(20*pi*t),10,100,kp,fs) ; 
[xc]=pmm(sin(20*pi*t),10,100,kp,fs) ;
data(index)=immse(xnb,xc) ;  
if data(index)<0.01
    keypi(index)=kp;

end
end
display(max([keypi]));
kp=-1:0.01:1
plot(kp,data)