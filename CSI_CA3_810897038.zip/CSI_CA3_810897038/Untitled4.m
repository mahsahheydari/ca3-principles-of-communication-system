f=(1000/2)*linspace(-1,1,1000);
b2=double(BesselFuncSeries(10,0.1,10,10,1000,2));
B2=fftshift(fft(b2));
plot(f,real(B2))
xlim([-500 500]);
title("single tone modulation expansion for \beta=0.1");
xlabel("freq(Hz)");
ylabel("xc");

f=(1000/2)*linspace(-1,1,1000);
x1=stm(10,10,0.1,10,1000);
X1=fftshift(fft(x1));
scatter(f,real(X1))
xlim([-500 500]);
title("single tone modulation for \beta=0.1");
xlabel("freq(Hz)");
ylabel("xc");