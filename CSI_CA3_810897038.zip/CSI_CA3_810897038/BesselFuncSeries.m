function [xc] = BesselFuncSeries(Ac,beta,fc,fm,fs,N)
t=0:1/fs:1-(1/fs);
syms n;
xc=symsum(Ac.*besselj(n,beta).*cos(2*pi.*(fc+n.*fm).*t),n,-N,N);
end