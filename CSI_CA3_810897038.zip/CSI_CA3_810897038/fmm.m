function [xcfm] = fmm(mt,Ac,fc,kf,fs)
t= 0: 1/fs: 0.2-(1/fs);
mm= 2*pi*trapz(mt);
kp=2*pi*kf;
xcfm=pmm(mm,Ac,fc,kp,fs);
end