function [xc]=pmm(mt,Ac,fc,kp,fs) 
t=0:1/fs:(0.2)-(1/fs);
xc=Ac*cos((2*pi*fc*t)+(kp.*mt));
end